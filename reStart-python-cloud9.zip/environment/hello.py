print("hello good afternoon")
